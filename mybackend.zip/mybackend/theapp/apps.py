from django.apps import AppConfig


class TheappConfig(AppConfig):
    name = 'theapp'
